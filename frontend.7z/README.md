# Endless Discovery
The front end of Endless Discovery written in Vue with Tailwind CSS, built via Vite.